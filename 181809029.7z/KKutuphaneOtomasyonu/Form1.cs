﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KKutuphaneOtomasyonu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GirisYap(txtID.Text,txtPWD.Text);   
        }
        void GirisYap(string id,string pwd) {
            Listele();
            for (int i = 0; i < liste.Count; i++)
            {
                id = liste[i].GetID();
                pwd = liste[i].GetPWD();
            }
            if (id == txtID.Text && pwd == txtPWD.Text)
            {
                UI.AnaEkran anaEkran = new UI.AnaEkran();
                anaEkran.Show();
            }
            else
            {
                MessageBox.Show("Lütfen Kullanıcı Adnınızı Ve Şifrenizi Kontrol Ediniz !");
            }
        }
        List<Database.db> liste = new List<Database.db>();
        List<Database.db> Listele()
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("select * from user_login", connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Database.db db = new Database.db();
                    db.SetID(reader.GetString(0));
                    db.SetPWD(reader.GetString(1));
                    liste.Add(db);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            return liste;
        }
    }
}
