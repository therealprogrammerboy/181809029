﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKutuphaneOtomasyonu.Database
{
	public class Kitap
	{

		private string ISBN;
		private string kitapAdi;
		private string yayinTarihi;
		private int sayfaSayisi;
		private string Yazari;
		private string KategoriAdi;
		private string KutuphaneAdi;

		public string getISBN()
		{
			return ISBN;
		}
		public void setISBN(string iSBN)
		{
			ISBN = iSBN;
		}
		public string getKitapAdi()
		{
			return kitapAdi;
		}
		public void setKitapAdi(string kitapAdi)
		{
			this.kitapAdi = kitapAdi;
		}
		public string getYayinTarihi()
		{
			return yayinTarihi;
		}
		public void setYayinTarihi(string yayinTarihi)
		{
			this.yayinTarihi = yayinTarihi;
		}
		public int getSayfaSayisi()
		{
			return sayfaSayisi;
		}
		public void setSayfaSayisi(int sayfaSayisi)
		{
			this.sayfaSayisi = sayfaSayisi;
		}
		public string getYazari()
		{
			return Yazari;
		}
		public void setYazari(string yazari)
		{
			Yazari = yazari;
		}
		public string getKategoriAdi()
		{
			return KategoriAdi;
		}
		public void setKategoriAdi(string kategoriAdi)
		{
			KategoriAdi = kategoriAdi;
		}
		public string getKutuphaneAdi()
		{
			return KutuphaneAdi;
		}
		public void setKutuphaneAdi(string kutuphaneAdi)
		{
			KutuphaneAdi = kutuphaneAdi;
		}
	}
}
