﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKutuphaneOtomasyonu.Database
{
	public class Kutuphane
	{
		public string kutuphaneAdi;
		public int kutNo;
		public string kutAciklama;
		public int kutAdresNo;

		public string getKutuphaneAdi()
		{
			return kutuphaneAdi;
		}
		public void setKutuphaneAdi(string kut_Adi)
		{
			kutuphaneAdi = kut_Adi;
		}
		public int getKutNo()
		{
			return kutNo;
		}
		public void setKutNo(int kutno)
		{
			kutNo = kutno;
		}
		public string getKutAciklama()
		{
			return kutAciklama;
		}
		public void setKutAciklama(string aciklama)
		{
			kutAciklama = aciklama;
		}
		public int getNo()
		{
			return kutAdresNo;
		}
		public void setNo(int no)
		{
			kutAdresNo = no;

		}
		public string toString()
		{
			return kutuphaneAdi;
		}
	}
}
