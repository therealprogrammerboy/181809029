﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKutuphaneOtomasyonu.Database
{
    public class Emanet
    {
        private int emanetNo;
        private string ISBN;
        private int uyeNo;
        private int kutuphaneNo;
        private string emanetTarihi;
        private string teslimTarihi;
        public int getEmanetNo() { return emanetNo; }
        public void setemanetNo(int emno) { emanetNo = emno; }
        public string getISBN() { return ISBN; }
        public void setISBN(string ısbn) { ISBN = ısbn; }
        public int getUyeNo() { return uyeNo; }
        public void setUyeNo(int uyeno) { uyeNo = uyeno; }
        public int getKutuphaneNo() { return kutuphaneNo; }
        public void setKutuphaneNo(int kutuphaneno) { kutuphaneNo = kutuphaneno; }
        public string getEmanetTarihi() { return emanetTarihi.ToString(); }
        public void setEmanetTarihi(string emanettarihi) { emanetTarihi = emanettarihi; }
        public string getTeslimTarihi() { return teslimTarihi.ToString(); }
        public void setTeslimTarihi(string tt) { teslimTarihi = tt; }
    }
}
