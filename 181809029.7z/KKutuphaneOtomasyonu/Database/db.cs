﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKutuphaneOtomasyonu.Database
{
    public class db
    {
        string id, pwd;
        public string GetID()
        {
            return id;
        }
        public void SetID(string a)
        {
            id = a;
        }
        public string GetPWD()
        {
            return pwd;
        }
        public void SetPWD(string b)
        {
            pwd = b;
        }
    }
}
