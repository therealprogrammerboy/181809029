﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.Database
{
    public class SqlVeritabanıBag
    {
        public void Emanet_Kaydet(double gelenISBN, int gelenUyeNo, int gelenKutNo, string verildigiTar, string iadeTar)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");                   
            string sorgu = "insert into Emanet (ISBN,Uye_No,Kutuphane_No,Emanet_Tarihi,Teslim_Tarihi) values(" + gelenISBN + "," + gelenUyeNo + "," + gelenKutNo + ",'" +verildigiTar + "','" + iadeTar + "')";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Eklendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Emanet_Sil(int gelenEmNo)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "delete from Emanet where Emanet_No=" + gelenEmNo + "";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Silindi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Emanet_Guncelle(double gelenEmNo, double gelenISBN, double gelenUyeNo, double gelenKutNo, DateTime verildigiTar, DateTime iadeTar)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "update Emanet set ISBN=" + gelenISBN + ",Uye_No=" + gelenUyeNo + ",Kutuphane_No=" + gelenKutNo + ",Emanet_Tarihi='" + verildigiTar + "',Teslim_Tarihi='" + iadeTar + "'";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Güncellendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public List<Emanet> EmanetListele()
        {
            List<Emanet> emanetListe = new List<Emanet>();
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            try
            {
                connection.Open();
                string sorgu = "select * from Emanet";
                SqlCommand command = new SqlCommand(sorgu, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Emanet emanet = new Emanet();
                    emanet.setemanetNo(reader.GetInt32(0));
                    emanet.setISBN(reader.GetString(1));
                    emanet.setUyeNo(reader.GetInt32(2));
                    emanet.setKutuphaneNo(reader.GetInt32(3));
                    emanet.setEmanetTarihi(reader.GetString(4));
                    emanet.setTeslimTarihi(reader.GetString(5));
                    emanetListe.Add(emanet);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
            return emanetListe;
        }
        public void Yazar_Kaydet(int no, string ad, string sad)
        {            
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "insert into Yazarlar (Yazar_No,Yazar_Adi,Yazar_Soyadi) values"
                 + "('" + no + "',"
                 + "'" + ad + "',"
                 + "'" + sad + "') ";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Eklendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Yazar_Sil(int yzno)
        {
            Yazar silyazar = new Yazar();
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "delete from Yazarlar where Yazar_No='" + yzno + "'";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Silindi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Yazar_Guncelle(int no, string yadi, string ysoyadi)
        {
            Yazar guncelleyazar = new Yazar();
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "update Yazarlar set "
                 + "Yazar_Adi='" + yadi + "', "
                 + "Yazar_Soyadi='" + ysoyadi + "'"
                 + "where Yazar_No='" + no + "'";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Güncellendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public List<Yazar> Yazar_Listele()
        {
            List<Yazar> liste = new List<Yazar>();
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            try
            {
                connection.Open();
                string sorgu = "select * from Yazarlar";
                SqlCommand command = new SqlCommand(sorgu, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Yazar yazar = new Yazar();
                    yazar.setYazar_No(reader.GetInt32(0));
                    yazar.setYazar_Adi(reader.GetString(1));
                    yazar.setYazar_Soyadi(reader.GetString(2));
                    liste.Add(yazar);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            return liste;
        }
        public void Uye_Kaydet(string adi, string sadi, string tel, string eposta, string cins, int adrsno)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "insert into UYELER(Uye_Adi,Uye_Soyadi,Cinsiyet,Adres_No,Telefon,E_posta) values('" + adi + "','" + sadi + "','" + cins + "'," + adrsno + ",'" + tel + "','" + eposta + "')";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Eklendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Uye_Sil(int no)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "delete from UYELER where Uye_No=" + no + "";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Silindi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Uye_Guncelle(string ad, string soyad, string cins, int adrsno, string tel, string posta, int uyeno)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "update UYELER set Uye_Adi='" + ad + "',Uye_Soyadi='" + soyad + "',Cinsiyet='" + cins + "',Adres_No=" + adrsno + ",Telefon='" + tel + "',E_posta='" + posta + "' where Uye_No=" + uyeno + "";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Güncellendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public List<Uye> UyeListele()
        {
            List<Uye> uyelist = new List<Uye>();
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "select * from UYELER";
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sorgu, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Uye uye = new Uye();
                    uye.setUye_No(reader.GetInt32(0));
                    uye.setUye_Adi(reader.GetString(1));
                    uye.setUye_Soyadi(reader.GetString(2));
                    uye.setCinsiyet(reader.GetString(3));
                    uye.setAdres_No(reader.GetInt32(4));
                    uye.setTelefon(reader.GetString(5));
                    uye.setEposta(reader.GetString(6));
                    uyelist.Add(uye);
                }
            }
            catch (Exception err)
            {
                // MessageBox.Show(err.Message);
            }
            return uyelist;
        }
        public void Adres_Ekle(string cad,string mah,string no,string sehir,int pkod)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "insert into Adresler(Cadde, Mahalle, Bina_No, Sehir, Posta_Kodu)values('" + cad + "', '" + mah + "', '" + no + "', '" + sehir + "', " + pkod + ")";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Eklendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Kategori_Ekle(int katno,string gelenKatAdi)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu= "insert into Kategoriler(Kategori_No,Kategori_Adi) values(" + katno + ",'" + gelenKatAdi + "')";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Eklendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Kategori_Sil(int gelenKatNo)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "delete from  Kategoriler where Kategori_No=" + gelenKatNo + "";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Silindi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Kategori_Guncelle(int gelenKatNo,string gelenKatAdi)
        {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "update Kategoriler set Kategori_Adi='" + gelenKatAdi + "' where Kategori_No=" + gelenKatNo + "";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Güncellendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public List<Kategori> Kategori_Listele() {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            List<Kategori> katlist = new List<Kategori>();
            string sorgu = "select * from Kategoriler";
            SqlCommand command = new SqlCommand(sorgu, connection);
           
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Kategori kategori = new Kategori();
                    kategori.setKategoriNo(reader.GetInt32(0));
                    kategori.setKategoriAdi(reader.GetString(1));
                    katlist.Add(kategori);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            return katlist;
        }
        public List<Kutuphane> Kutuphane_Listele()
        {
            List<Kutuphane> kutlist = new List<Kutuphane>();
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "select *  from Kutuphane";
            SqlCommand command = new SqlCommand(sorgu, connection);
            
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Kutuphane kutuphane = new Kutuphane();
                    kutuphane.setKutNo(reader.GetInt32(0));
                    kutuphane.setKutuphaneAdi(reader.GetString(1));
                    kutuphane.setKutAciklama(reader.GetString(2));
                    kutuphane.setKutNo(reader.GetInt32(3));
                    kutlist.Add(kutuphane);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            return kutlist;
        }
        public void Kitap_Ekle(string isbn,string kitapadi,int syfsayisi,string tarih,string katadi,string yazadi,string kutadi) {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "insert into Kitaplar(ISBN,Kitap_Adi,Yayin_Tarihi,S_Sayisi) values('"+isbn+"','"+kitapadi+"','"+tarih+ "'," + syfsayisi + ") ";
            string sorgu2 = "insert into Kategoriler(Kategori_Adi) values('" + katadi + "')";
            string sorgu3= "insert into Yazarlar(Yazar_Adi) values('"+yazadi+"')";
            string sorgu4= "insert into Kutuphane(Kutuphane_ismi) values('"+kutadi+"')";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlCommand command2 = new SqlCommand(sorgu2, connection);
            SqlCommand command3 = new SqlCommand(sorgu3, connection);
            SqlCommand command4 = new SqlCommand(sorgu4, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                command2.ExecuteNonQuery();
                command3.ExecuteNonQuery();
                command4.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Eklendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }

        }
        public void Kitap_Sil(string isbn) {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "delete from Kitaplar where ISBN='" + isbn + "'";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Silindi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public List<Kitap> Kitap_Listele()
        {
            List<Kitap> kitlist = new List<Kitap>();
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "select *  from Kitaplar";
            SqlCommand command = new SqlCommand(sorgu, connection);            
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Kitap kitap = new Kitap();
                    kitap.setISBN(reader.GetString(0));
                    kitap.setKitapAdi(reader.GetString(1));
                    kitap.setYayinTarihi(reader.GetString(2));
                    kitap.setSayfaSayisi(reader.GetInt32(3));
                    kitlist.Add(kitap);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            return kitlist;
        }
        public void Kutuphane_Ekle(string isim,string aciklama) {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "insert into Kutuphane (Kutuphane_ismi,Aciklama) values('" + isim + "','" + aciklama + "')";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Eklendi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
        public void Kutuphane_Sil(int no) {
            SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=Kutuphane;Trusted_Connection=True;");
            string sorgu = "delete from Kutuphane where Kutuphane_No=" + no + "";
            SqlCommand command = new SqlCommand(sorgu, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Kayıt Silindi !");
                connection.Close();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
            }
        }
    }
}
