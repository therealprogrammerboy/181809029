﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKutuphaneOtomasyonu.Database
{
	public class Uye
	{
		private int Uye_No;
		private string Uye_Adi;
		private string Uye_Soyadi;
		private string Cinsiyet;
		private string Telefon;
		private string E_Posta;
		private int Adres_No;
		public Uye() { }

		public int getUye_no()
		{
			return Uye_No;
		}
		public void setUye_No(int uye_no)
		{
			Uye_No = uye_no;
		}
		public string getUyeAdi()
		{
			return Uye_Adi;
		}
		public void setUye_Adi(string uye_adi)
		{
			Uye_Adi = uye_adi;
		}
		public string getUye_Soyadi()
		{
			return Uye_Soyadi;
		}
		public void setUye_Soyadi(string uye_soyadi)
		{
			Uye_Soyadi = uye_soyadi;
		}

		public string getCinsiyet()
		{
			return Cinsiyet;
		}
		public void setCinsiyet(string cinsiyet)
		{
			Cinsiyet = cinsiyet;
		}

		public string getTelefon()
		{
			return Telefon;
		}

		public void setTelefon(string telefon)
		{
			Telefon = telefon;
		}
		public string getEposta()
		{
			return E_Posta;
		}
		public void setEposta(string eposta)
		{
			E_Posta = eposta;
		}
		public int getAdres_No()
		{
			return Adres_No;
		}
		public void setAdres_No(int adres_no)
		{
			Adres_No = adres_no;
		}
	}
}
