﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKutuphaneOtomasyonu.Database
{
	public class Kategori
	{
		private int kategoriNo;
		private string kitapKategori;
		public Kategori() { }
		public int getKategoriNo()
		{
			return kategoriNo;
		}

		public void setKategoriNo(int katno)
		{
			kategoriNo = katno;
		}

		public string getKategoriAdi()
		{
			return kitapKategori;
		}
		public void setKategoriAdi(string kategoriAdi)
		{
			kitapKategori = kategoriAdi;
		}
		public string toString()
		{
			return kitapKategori;
		}
	}
}
