﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKutuphaneOtomasyonu.Database
{
    public class Yazar
    {

        private int Yazar_No;
        private string Yazar_Adi;
        private string Yazar_Soyadi;

        public Yazar()
        {

        }

        public int getYazar_No()
        {
            return Yazar_No;
        }

        public void setYazar_No(int yazar_No)
        {
            Yazar_No = yazar_No;
        }

        public string getYazar_Adi()
        {
            return Yazar_Adi;
        }

        public void setYazar_Adi(string yazar_Adi)
        {
            Yazar_Adi = yazar_Adi;
        }

        public string getYazar_Soyadi()
        {
            return Yazar_Soyadi;
        }

        public void setYazar_Soyadi(string yazar_Soyadi)
        {
            Yazar_Soyadi = yazar_Soyadi;
        }


        public string toString()
        {
            return Yazar_Adi + " " + Yazar_Soyadi;
        }
    }
}
