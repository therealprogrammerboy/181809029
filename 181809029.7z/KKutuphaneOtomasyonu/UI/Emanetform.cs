﻿using KKutuphaneOtomasyonu.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.UI
{
    public partial class Emanetform : Form
    {
        public Emanetform()
        {
            InitializeComponent();
        }       
        Database.SqlVeritabanıBag sqlVeritabanı = new Database.SqlVeritabanıBag();
        List<Emanet> emlist = new SqlVeritabanıBag().EmanetListele();
        object[] data = new object[6];        
        private void button1_Click(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy-mm-dd"; 
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "yyyy-mm-dd";
            string tarih1 = dateTimePicker1.Value.ToString();
            string tarih2 = dateTimePicker2.Value.ToString();
            //int emno = Convert.ToInt32(txtEmNo.Text);
            double isbn = Convert.ToDouble(txtIsbn.Text);
            int uyeno = Convert.ToInt32(txtUyeNo.Text);
            int kutno = Convert.ToInt32(txtKutNo.Text);
            sqlVeritabanı.Emanet_Kaydet(isbn, uyeno, kutno,tarih1,tarih2);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sqlVeritabanı.Emanet_Sil(Convert.ToInt32(txtEmNo.Text));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd-MM-yyyy";
            sqlVeritabanı.Emanet_Guncelle(Convert.ToDouble(txtEmNo.Text), Convert.ToDouble(txtIsbn.Text), Convert.ToDouble(txtUyeNo.Text), Convert.ToDouble(txtKutNo.Text), Convert.ToDateTime(dateTimePicker1.Value), Convert.ToDateTime(dateTimePicker2.Value));
        }
        
        void EmanetListele()
        {
            for (int i = 0; i <emlist.Count; i++)
            {
                data[0] = emlist[i].getEmanetNo();
                data[1] = emlist[i].getISBN();
                data[2] = emlist[i].getUyeNo();
                data[3] = emlist[i].getKutuphaneNo();
                data[4] = emlist[i].getEmanetTarihi();
                data[5] = emlist[i].getTeslimTarihi();
                dataGridView1.Rows.Add(data);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            EmanetListele();
        }
    }
}
