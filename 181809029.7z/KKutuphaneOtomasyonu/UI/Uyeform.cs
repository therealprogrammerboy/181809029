﻿using KKutuphaneOtomasyonu.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.UI
{
    public partial class Uyeform : Form
    {
        public Uyeform()
        {
            InitializeComponent();
        }
        SqlVeritabanıBag sqlVeritabanıBag = new SqlVeritabanıBag();
        List<Uye> uyeliste = new SqlVeritabanıBag().UyeListele();
        object[] o = new object[7];

        private void button1_Click(object sender, EventArgs e)
        {
            string cinsiyet="";
            if (rdErkek.Checked)
            {
                cinsiyet = "Erkek";
            }
            else if (rdErkek.Checked && rdKAdin.Checked)
            {
                MessageBox.Show("Cinsiyetlerden Sadece Birini Seçiniz !");
            }
            else
            {
                cinsiyet = "Kadın";
            }
            sqlVeritabanıBag.Uye_Kaydet(txtAd.Text,txtSad.Text,txtTel.Text,txtEposta.Text,cinsiyet,Convert.ToInt32(txtAdresNo.Text));
        }
        void UyeListele()
        {
            for (int i = 0; i < uyeliste.Count; i++)
            {
                o[0] = uyeliste[i].getUye_no();
                o[1] = uyeliste[i].getUyeAdi();
                o[2] = uyeliste[i].getUye_Soyadi();
                o[3] = uyeliste[i].getCinsiyet();
                o[4] = uyeliste[i].getEposta();
                o[5] = uyeliste[i].getTelefon();
                o[6] = uyeliste[i].getAdres_No();
                dataGridView1.Rows.Add(o);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sqlVeritabanıBag.Uye_Sil(Convert.ToInt32(txtNo.Text));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string cinsiyet = "";
            if (rdErkek.Checked)
            {
                cinsiyet = "Erkek";
            }
            else if (rdErkek.Checked && rdKAdin.Checked)
            {
                MessageBox.Show("Cinsiyetlerden Sadece Birini Seçiniz !");
            }
            else
            {
                cinsiyet = "Kadın";
            }
            sqlVeritabanıBag.Uye_Guncelle(txtAd.Text, txtSad.Text, cinsiyet, Convert.ToInt32(txtAdresNo.Text), txtTel.Text, txtEposta.Text, Convert.ToInt32(txtAdresNo.Text));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UyeListele();
        }
    }
}
