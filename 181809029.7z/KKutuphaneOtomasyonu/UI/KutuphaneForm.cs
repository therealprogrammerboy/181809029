﻿using KKutuphaneOtomasyonu.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.UI
{
    public partial class KutuphaneForm : Form
    {
        public KutuphaneForm()
        {
            InitializeComponent();
        }
        SqlVeritabanıBag bag = new SqlVeritabanıBag();
        List<Kutuphane> kutuphanes = new SqlVeritabanıBag().Kutuphane_Listele();
        object[] o = new object[4];
        private void button1_Click(object sender, EventArgs e)
        {
            bag.Kutuphane_Ekle(txtadi.Text, txtinfo.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bag.Kutuphane_Sil(Convert.ToInt32(txtno.Text));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Listele();
        }
        void Listele()
        {
            for (int i = 0; i < kutuphanes.Count; i++)
            {
                o[0] = kutuphanes[i].getKutNo();
                o[1] = kutuphanes[i].getKutuphaneAdi();
                o[2] = kutuphanes[i].getKutAciklama();
                o[3] = kutuphanes[i].getNo();
                dataGridView1.Rows.Add(o);
            }
        }
    }
}
