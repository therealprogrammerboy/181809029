﻿using KKutuphaneOtomasyonu.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.UI
{
    public partial class Yazarform : Form
    {
        public Yazarform()
        {
            InitializeComponent();
        }
        SqlVeritabanıBag sqlVeritabanıBag = new SqlVeritabanıBag();
        List<Yazar> yzlist = new SqlVeritabanıBag().Yazar_Listele();
        object[] o = new object[3];
        private void button1_Click(object sender, EventArgs e)
        {
            sqlVeritabanıBag.Yazar_Kaydet(Convert.ToInt32(txtYazarNo.Text),txtYazarAdi.Text,txtYazarSoyadi.Text);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            sqlVeritabanıBag.Yazar_Sil(Convert.ToInt32(txtYazarNo.Text));
        }
        private void button3_Click(object sender, EventArgs e)
        {
            sqlVeritabanıBag.Yazar_Guncelle(Convert.ToInt32(txtYazarNo.Text), txtYazarAdi.Text, txtYazarSoyadi.Text);
        }
        void Yazar_Listele()
        {
            for (int i = 0; i < yzlist.Count; i++)
            {
                o[0] = yzlist[i].getYazar_No();
                o[1] = yzlist[i].getYazar_Adi();
                o[2] = yzlist[i].getYazar_Soyadi();
                dataGridView1.Rows.Add(o);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Yazar_Listele();
        }
    }
}
