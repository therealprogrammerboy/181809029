﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.UI
{
    public partial class AnaEkran : Form
    {
        public AnaEkran()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Emanetform emanetform = new Emanetform();
            emanetform.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Yazarform yazarform = new Yazarform();
            yazarform.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Uyeform uyeform = new Uyeform();
            uyeform.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AdresEkle adresEkle = new AdresEkle();
            adresEkle.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            KategoriForm kategoriForm = new KategoriForm();
            kategoriForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Kitapform kitapform = new Kitapform();
            kitapform.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            KutuphaneForm kutuphaneForm = new KutuphaneForm();
            kutuphaneForm.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Arama arama = new Arama();
            arama.Show();
        }
    }
}
