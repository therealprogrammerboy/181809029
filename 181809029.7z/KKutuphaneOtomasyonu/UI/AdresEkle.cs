﻿using KKutuphaneOtomasyonu.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.UI
{
    public partial class AdresEkle : Form
    {
        public AdresEkle()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlVeritabanıBag sqlVeritabanıBag = new SqlVeritabanıBag();
            sqlVeritabanıBag.Adres_Ekle(txtCad.Text,txtMah.Text,txtBinano.Text,txtSehir.Text,Convert.ToInt32(txtPostalCode.Text));
        }
    }
}
