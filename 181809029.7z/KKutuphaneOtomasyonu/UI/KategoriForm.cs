﻿using KKutuphaneOtomasyonu.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.UI
{
    public partial class KategoriForm : Form
    {
        public KategoriForm()
        {
            InitializeComponent();
        }
        SqlVeritabanıBag sqlVeritabanıBag = new SqlVeritabanıBag();
        List<Kategori> kategoris = new SqlVeritabanıBag().Kategori_Listele();
        object[] o = new object[2];
        private void button1_Click(object sender, EventArgs e)
        {
            sqlVeritabanıBag.Kategori_Ekle(Convert.ToInt32(textBox1.Text),textBox2.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sqlVeritabanıBag.Kategori_Sil(Convert.ToInt32(textBox1.Text));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sqlVeritabanıBag.Kategori_Guncelle(Convert.ToInt32(textBox1.Text), textBox2.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
           Kategori_Listele();
        }
        void Kategori_Listele()
        {
            for (int i = 0; i < kategoris.Count; i++)
            {
                o[0] = kategoris[i].getKategoriNo();
                o[1] = kategoris[i].getKategoriAdi();
                dataGridView1.Rows.Add(o);
            }
        }
    }
}
