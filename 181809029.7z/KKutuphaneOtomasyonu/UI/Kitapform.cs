﻿using KKutuphaneOtomasyonu.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KKutuphaneOtomasyonu.UI
{
    public partial class Kitapform : Form
    {
        public Kitapform()
        {
            InitializeComponent();
        }
        List<Kitap> liste = new SqlVeritabanıBag().Kitap_Listele();
        List<Yazar> Yazarliste = new SqlVeritabanıBag().Yazar_Listele();
        List<Kategori> KategoriListe = new SqlVeritabanıBag().Kategori_Listele();
        List<Kutuphane> KutuphaneListe = new SqlVeritabanıBag().Kutuphane_Listele();
        object[] o = new object[4];
        object[] objKatAdi = new object[1];        
        object[] objKutAdi = new object[1];
        SqlVeritabanıBag bag = new SqlVeritabanıBag();
        void Kitap_Listele()
        {
            for (int i = 0; i < liste.Count; i++)
            {
                o[0] = liste[i].getISBN();
                o[1] = liste[i].getKitapAdi();
                o[2] = liste[i].getYayinTarihi();
                o[3] = liste[i].getSayfaSayisi();
                dataGridView1.Rows.Add(o);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Kitap_Listele();
        }

        private void Kitapform_Load(object sender, EventArgs e)
        {
            KatAdiGoster();            
            KutGoster();
            
        }
        void KatAdiGoster()
        {
            for (int i = 0; i < KategoriListe.Count; i++)
            {
                objKatAdi[0] = KategoriListe[i].getKategoriAdi();
                cmbbxKat.Items.AddRange(objKatAdi);
            }
        }       
        void KutGoster() {
            for (int i = 0; i < KutuphaneListe.Count; i++)
            {
                objKutAdi[0] = KutuphaneListe[i].getKutuphaneAdi();
                cmbbxKutuphanesi.Items.AddRange(objKutAdi);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bag.Kitap_Ekle(txtISBN.Text, txtKitAdi.Text, Convert.ToInt32(txtSayfSay.Text), Convert.ToString(dateTimePicker1.Value), Convert.ToString(cmbbxKat.Text), txtYazari.Text, Convert.ToString(cmbbxKutuphanesi.Text));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bag.Kitap_Sil(txtISBN.Text);
        }
    }
}
